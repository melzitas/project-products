const Product = require('../models/relatorioModel');  
const PdfPrinter = require('pdfmake');

// EXIBIR TODOS OS USUÁRIOS

exports.getAllProducts = (req, res) => {  
    Product.getAllProducts((products) => {  
        if (!Array.isArray(products)) {
            console.error('Error: retorno de getAllproducts não é um array.');  
            return res.status(500).send('Erro ao buscar produtos.');  
        }
        res.render('relatorio', { products });  
    });
};

// Função para gerar o PDF
async function gerarPDF(products) {
    const fonts = {
        Roboto: { 
            normal: 'node_modules/pdfmake/fonts/Roboto-Regular.ttf',  
            bold: 'node_modules/pdfmake/fonts/Roboto-Bold.ttf',
            italics: 'node_modules/pdfmake/fonts/Roboto-Italic.ttf',
            bolditalics: 'node_modules/pdfmake/fonts/Roboto-BoldItalic.ttf',
        },
    };

    const printer = new PdfPrinter(fonts);

    const docDefinition = {
        content: [
            { text: 'Relatório de Produtos', style: 'header' },  
            {
                table: {
                    headerRows: 1,
                    widths: ['auto', '*', '*', '*', '*', '*', '*', '*'],
                    body: [
                        ['ID', 'Nome', 'Descricao', 'Fornecedor', 'Marca', 'Preço compra', 'Preço de venda', 'Estoque'],   
                        ...products.map(product => [product.id_prod, product.nome, product.descricao, product.fornecedor, product.marca, product.precocompra, product.precovenda, product.estoque]),
                    ],
                },
            }
        ],
        styles: {
            header: {
                fontSize: 18,
                bold: true,
                margin: [0, 0, 0, 10],
            },
        },
    };

    const pdfDoc = printer.createPdfKitDocument(docDefinition);
    const chunks = [];
    return new Promise((resolve, reject) => {
        pdfDoc.on('data', chunk => chunks.push(chunk));
        pdfDoc.on('end', () => resolve(Buffer.concat(chunks)));
        pdfDoc.on('error', reject);
        pdfDoc.end();
    });
}

// GERAR RELATÓRIO EM PDF
exports.generatePDF = async (req, res) => {
    const products = await Product.getAllProductstoPDF();
    const pdfBuffer = await gerarPDF(products);  

    res.setHeader('Content-Type', 'application/pdf');
    res.setHeader('Content-Disposition', 'attachment; filename=relatorio.pdf');  // Fixed relationio
    res.send(pdfBuffer);
};
